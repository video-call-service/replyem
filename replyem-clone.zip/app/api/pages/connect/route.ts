import { getServerSession } from "next-auth/next"
import { NextResponse } from "next/server"
import { authOptions } from "../../auth/[...nextauth]/route"
import { prisma } from "@/lib/db/prisma"

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)

  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 })
  }

  try {
    const { pageId } = await request.json()

    // Fetch page details from Facebook
    const response = await fetch(
      `https://graph.facebook.com/v18.0/${pageId}?fields=name,access_token&access_token=${session.accessToken}`,
    )
    const pageData = await response.json()

    // Save page to database
    const page = await prisma.page.create({
      data: {
        userId: session.user.id,
        pageId: pageData.id,
        pageName: pageData.name,
        accessToken: pageData.access_token,
      },
    })

    return NextResponse.json(page)
  } catch (error) {
    console.error("Error connecting page:", error)
    return new NextResponse("Internal Server Error", { status: 500 })
  }
}


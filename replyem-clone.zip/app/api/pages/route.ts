import { getServerSession } from "next-auth/next"
import { NextResponse } from "next/server"
import { authOptions } from "../auth/[...nextauth]/route"
import { prisma } from "@/lib/db/prisma"

export async function GET() {
  const session = await getServerSession(authOptions)

  if (!session) {
    return new NextResponse("Unauthorized", { status: 401 })
  }

  try {
    // Fetch user's Facebook pages using Graph API
    const response = await fetch(`https://graph.facebook.com/v18.0/me/accounts?access_token=${session.accessToken}`)
    const data = await response.json()

    // Get connected pages from database
    const connectedPages = await prisma.page.findMany({
      where: {
        userId: session.user.id,
      },
      select: {
        pageId: true,
      },
    })

    const connectedPageIds = connectedPages.map((page) => page.pageId)

    // Combine Facebook data with connected status
    const pages = data.data.map((page: any) => ({
      ...page,
      connected: connectedPageIds.includes(page.id),
    }))

    return NextResponse.json(pages)
  } catch (error) {
    console.error("Error fetching pages:", error)
    return new NextResponse("Internal Server Error", { status: 500 })
  }
}


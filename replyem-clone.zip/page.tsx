import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-500 to-blue-400">
      {/* Navigation */}
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <Link href="/" className="text-white text-2xl font-bold">
              replyem
            </Link>
            <div className="hidden md:flex space-x-6">
              <Link href="#how-it-works" className="text-white hover:text-blue-100">
                How it works
              </Link>
              <Link href="#features" className="text-white hover:text-blue-100">
                Features
              </Link>
              <Link href="#pricing" className="text-white hover:text-blue-100">
                Pricing
              </Link>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <Link href="/blog" className="text-white hover:text-blue-100">
              Blog
            </Link>
            <Link href="/support" className="text-white hover:text-blue-100">
              Support
            </Link>
            <Button variant="secondary" className="bg-white text-blue-600 hover:bg-blue-50">
              Sign in
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-4xl md:text-5xl font-bold text-white leading-tight">
              Send hundreds of inbox messages to your customers from your facebook page.
            </h1>
            <p className="text-xl text-blue-50">
              Send targeted inbox messages by thousands to the people that has already started a conversation with your
              page.
            </p>
            <Button className="bg-green-400 hover:bg-green-500 text-white px-8 py-6 text-lg">
              TRY IT FREE FOR 30 DAYS
            </Button>
          </div>
          <div className="bg-white rounded-lg p-8 shadow-xl">
            <h2 className="text-4xl font-bold text-blue-600 mb-2">HOW TO SEND</h2>
            <h3 className="text-2xl font-bold text-blue-600">
              A MESSAGE TO ALL
              <br />
              THE PEOPLE IN YOUR PAGE&apos;S INBOX.
            </h3>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="bg-white py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-gray-200 mb-12 text-center">HOW IT WORKS</h2>
          <p className="text-xl text-gray-600 text-center max-w-3xl mx-auto">
            With Reply&apos;em you can reply to many comments at the same time, assign labels to your users, select the
            users on your inbox by label or by keywords and send them an inbox message to all of them in one click...
            awesome right?
          </p>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-white mb-12">FEATURES</h2>
          <div className="grid md:grid-cols-2 gap-12">
            <div className="bg-white rounded-lg p-8 shadow-xl">
              <h3 className="text-xl font-bold text-gray-800 mb-4">SEND MESSAGES TO THE PEOPLE IN YOUR INBOX</h3>
              <p className="text-gray-600">
                Imagine sending promotions to the people who already showed interest in your business. With
                Reply&apos;em you can send laser targeted messages to all the people in your Facebook page&apos;s inbox.
              </p>
            </div>
            <div className="bg-white rounded-lg p-8 shadow-xl">
              <h3 className="text-xl font-bold text-gray-800 mb-4">
                LABEL USERS RIGHT FROM YOUR POSTS, NOT ONLY FROM YOUR INBOX
              </h3>
              <p className="text-gray-600">
                You have the ability to separate your customers by categories using labels, so you can organize your
                leads by product, interest, service or any tag that works for you and your business. With Reply&apos;em
                you can label your users right from your posts.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}


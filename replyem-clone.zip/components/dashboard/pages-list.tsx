"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"

export function PagesList() {
  const [pages, setPages] = useState([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    fetchPages()
  }, [])

  const fetchPages = async () => {
    try {
      const response = await fetch("/api/pages")
      const data = await response.json()
      setPages(data)
      setLoading(false)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch Facebook pages",
        variant: "destructive",
      })
      setLoading(false)
    }
  }

  const connectPage = async (pageId: string) => {
    try {
      const response = await fetch("/api/pages/connect", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ pageId }),
      })
      if (response.ok) {
        toast({
          title: "Success",
          description: "Page connected successfully",
        })
        fetchPages()
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to connect page",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return <div>Loading your Facebook pages...</div>
  }

  return (
    <div className="grid gap-6">
      <h2 className="text-2xl font-bold">Your Facebook Pages</h2>
      <div className="grid gap-4">
        {pages.map((page: any) => (
          <Card key={page.id} className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">{page.name}</h3>
                <p className="text-sm text-gray-500">{page.id}</p>
              </div>
              <Button onClick={() => connectPage(page.id)} disabled={page.connected}>
                {page.connected ? "Connected" : "Connect"}
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}


import Link from "next/link"
import { Button } from "@/components/ui/button"
import { UserNav } from "./user-nav"

export function DashboardHeader() {
  return (
    <header className="border-b bg-white">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link href="/dashboard" className="text-xl font-bold">
            replyem
          </Link>
          <div className="flex items-center space-x-4">
            <Button variant="outline">Help</Button>
            <UserNav />
          </div>
        </div>
      </div>
    </header>
  )
}


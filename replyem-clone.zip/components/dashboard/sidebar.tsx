import Link from "next/link"
import { MessageSquare, Tag, Users, BarChart, Settings } from "lucide-react"

export function DashboardSidebar() {
  return (
    <aside className="w-64 bg-white border-r min-h-screen p-4">
      <nav className="space-y-2">
        <Link href="/dashboard/messages" className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-gray-100">
          <MessageSquare className="w-5 h-5" />
          <span>Messages</span>
        </Link>
        <Link href="/dashboard/labels" className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-gray-100">
          <Tag className="w-5 h-5" />
          <span>Labels</span>
        </Link>
        <Link
          href="/dashboard/subscribers"
          className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-gray-100"
        >
          <Users className="w-5 h-5" />
          <span>Subscribers</span>
        </Link>
        <Link
          href="/dashboard/analytics"
          className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-gray-100"
        >
          <BarChart className="w-5 h-5" />
          <span>Analytics</span>
        </Link>
        <Link href="/dashboard/settings" className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-gray-100">
          <Settings className="w-5 h-5" />
          <span>Settings</span>
        </Link>
      </nav>
    </aside>
  )
}


import type React from "react"

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary"
}

export const Button: React.FC<ButtonProps> = ({ children, variant = "primary", ...props }) => {
  return (
    <button
      className={`
        ${
          variant === "primary"
            ? "bg-blue-500 text-white hover:bg-blue-700"
            : "bg-gray-100 text-gray-800 hover:bg-gray-300"
        }
        px-4 py-2 rounded-md font-medium
      `}
      {...props}
    >
      {children}
    </button>
  )
}

